from sklearn.preprocessing import RobustScaler, MinMaxScaler, MaxAbsScaler, StandardScaler

from keras.models import Sequential
from keras.layers import Dense, PReLU, LeakyReLU, Dropout
from keras.callbacks import EarlyStopping
from keras.utils import to_categorical
from keras import optimizers
import tensorflow as tf


def train(data, feature):
    """
    :param data: pandas dataframe
    :param feature: list of features to train the model
    :return:  history of training and also loss and accuracy of validation set
    """

    label = ['TOC']
    x_train, x_valid, y_train, y_valid = train_test_split(data[feature], data[label], test_size=0.2, random_state=1)

    scaler = RobustScaler()
    x_train_scaled = scaler.fit_transform(x_train)
    x_valid_scaled = scaler.transform(x_valid)

    Dratio = 0.2

    # 2. 모델 구성하기 (To configure a model)
    model = Sequential()
    model.add(Dense(256, input_dim=len(feature), activation=PReLU(alpha_initializer="zeros")))
    model.add(Dropout(Dratio))

    model.add(Dense(64, activation=PReLU(alpha_initializer="zeros")))
    model.add(Dropout(Dratio))

    model.add(Dense(16, activation=PReLU(alpha_initializer="zeros")))
    model.add(Dropout(Dratio))

    model.add(Dense(4, activation=PReLU(alpha_initializer="zeros")))
    model.add(Dropout(Dratio))

    model.add(Dense(1))

    # 3. 모델 학습과정 설정하기 (Setting up a model course)
    adam = optimizers.Nadam(lr=0.0005)
    sgd = optimizers.SGD(lr=0.001, decay=1e-6, momentum=0.9, nesterov=True)
    rms = optimizers.RMSprop(lr=0.001)
    model.compile(optimizer=adam, loss='mse', metrics=['mae'])

    # 4. 모델 학습시키기 (To train a model)
    hist = model.fit(x_train_scaled, y_train, epochs=500, batch_size=10000)

    return hist, model.evaluate(x_valid_scaled, y_valid, batch_size=12)


def inspect():
    import itertools

    features = ['Temp', 'pH', 'EC', 'Do', 'Turb']
    features = list(itertools.permutations(features, 3))
    ls_models = []
    for feature_combination in features:
        result = {}
        result['feature_combination'] = feature_combination
        result['history'], result['loss'] = train(data, feature_combination)
        ls_models.append(result)


inspect()
